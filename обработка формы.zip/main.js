// btn.onclick = function (event) {
//   event.preventDefault();
//   console.log("btn");
// };
document.querySelector("#btn").onclick = (event) => {
  event.preventDefault();
  let form = document.querySelector("form");
  console.log(form.elements.exampleInputEmail1.value);
  console.log(form.elements.exampleInputPassword1.value);
  // let text = document.querySelector("#exampleInputEmail1");
  // let text2 = document.querySelector("#exampleInputPassword1");
  // console.log(text, text2.value);
};
//
//
// function addRow() {
//   var table = document.getElementById("results");
//   var row = document.createElement("tr");
//   var td1 = document.createElement("td");
//   var td2 = document.createElement("td");
//   var td3 = document.createElement("td");
//   td1.innerHTML = document.getElementById("name").value;
//   td2.innerHTML = document.getElementById("lname").value;
//   td3.innerHTML = document.getElementById("gender").value;
//   row.appendChild(td1);
//   row.appendChild(td2);
//   row.appendChild(td3);
//   table.children[0].appendChild(row);
// }
// function qqqq() {
//   var table = document.getElementById("results");
//   var first = document.createElement("td");
//   var last = document.createElement("td");
//   firs.innerHTML = document.getElementById("exampleInputEmail1").value;
//   last.innerHTML = document.getElementById("").value;
// }

// let select = document.getElementById("#exampleInputEmail1");
// select.onchange = function (avent) {
//   console.log(select.value);
// };

// function sform() {
//   document.forms["exampleInputEmail1"].submit();
//   console.log(1);
// }

// document.forms[exampleInputEmail1].submit();
// console.log(1);
// $(document).ready(function () {
//   $("#form-todu").submit(function (evt) {
//     evt.preventDefault();
//     console.log(333);
//   });
// });
//

// let form = document.createElement("form");
// form.action = "https://google.com/search";
// form.method = "GET";

// form.innerHTML = '<input name="q" value="test">';

// // перед отправкой формы, её нужно вставить в документ
// document.body.append(form);

// form.submit();
